import { Box, Typography } from '@mui/material'
import React from 'react'
import './css/about.css'

const About = () => {
  return (
    <div className='about'>
      <Box display  ='flex' flexDirection='column' alignItems= 'center'>
        <Typography sx={{fontFamily:"fantasy", color:'white' }} margin='50px' variant='h2'>This is the Online Book-Store </Typography>
        <Typography sx={{fontFamily:"inherit", fontSize:'20px', fontStyle:'Italic', color:'white'}} padding='5px' variant='p'>Online Book store is an online web application where the customer can purchase books online.</Typography>
        <Typography sx={{fontFamily:"inherit", fontSize:'20px', fontStyle:'Italic', color:'white'}} padding='5px' variant='p'>You can add books using add product function.</Typography>
        <Typography sx={{fontFamily:"inherit", fontSize:'20px', fontStyle:'Italic', color:'white'}} padding='5px' variant='p'>All the added books are stored in books section.</Typography>
        <Typography sx={{fontFamily:"inherit", fontSize:'20px', fontStyle:'Italic', color:'white'}} padding='5px' variant='p'>Also you can update or delete the added books.</Typography>
      </Box>
    </div>
  )
}

export default About