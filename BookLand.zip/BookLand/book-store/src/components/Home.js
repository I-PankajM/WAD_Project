import { Box, Button, Typography } from '@mui/material';

import React from 'react';
import { Link } from 'react-router-dom';
import "./css/home.css"

const Home = () => {
    return <div className='Home'>
        <Box display='flex' flexDirection="column" alignItems="center">
        <Typography sx={{fontFamily:"fantasy", color: "White"}} variant='h2' marginTop='40px' > Welcome to Book Land </Typography>
            <Button className='button' LinkComponent={Link} 
            to="/books" 
            sx ={{marginTop:15, background:'orangered', "&:hover":{background: '#030b45',  transform: 'scale(1.1)' }}} variant='contained'>
                
                
               <Typography variant='h3'>View All Books</Typography> 
            </Button> 
        </Box>
    </div>;

}

export default Home;