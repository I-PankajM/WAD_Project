import React, { useState } from 'react'
import { AppBar, Tab, Tabs, Toolbar, Typography } from '@mui/material';
import LibraryBooksOutlinedIcon from '@mui/icons-material/LibraryBooksOutlined';
import { NavLink} from 'react-router-dom'
const Header = () => {
    const [value, setValue] = useState();
    return (
        <div className='header'>
            <AppBar sx ={{backgroundColor:'#030b45'}}position="sticky">
                <Toolbar>
                    <NavLink to="/"  style={{color: "White"}}  >
                    <Typography><LibraryBooksOutlinedIcon sx = {{ "&:hover":{ transform: 'scale(1.1)'}}}></LibraryBooksOutlinedIcon></Typography>
                    </NavLink>
                    <Tabs
                    sx = {{ml:'auto'}}
                        textColor="primary" indicatorColor='primary' value={value} onChange={( val) => setValue(val)}>
                        <Tab LinkComponent={NavLink} to ="/add" label="Add Product" style={{color: "White"}}  sx = {{ "&:hover":{ transform: 'scale(1.2)' }}} />
                        <Tab LinkComponent={NavLink} to ="/books" label="Books"  style={{color: "White"}} sx = {{ "&:hover":{ transform: 'scale(1.2)' }}} />
                        <Tab LinkComponent={NavLink} to ="/about" label="About Us"  style={{color: "white"}} sx = {{ "&:hover":{ transform: 'scale(1.2)' }}} />
                    </Tabs>
                </Toolbar>

            </AppBar>
        </div>
    );
};

export default Header;