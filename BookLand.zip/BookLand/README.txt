<------------Book-store Website------------->

#Download the zip file 

#Extract the file  

#Open the extracted folder in VS code

#Create the database book-store and inside that create the collection books using mongoDB cluster 

#Install the prerequisites for backend

-npm install 

-npm i nodemon,express,mongoose,cors

#Install the prerequisites for Frontend

-Run the following command 
-npx create-react-app book-store
-and replace the extracted book-store folder with this

-npm install @mui/material @emotion/react @emotion/styled @mui/icons-material
(You can get this libraries on material UI website)

-npm install react-router-dom@6

#Create the database using mongoDB cluster 


